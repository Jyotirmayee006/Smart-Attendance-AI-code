from __future__ import annotations

import os
import csv
import cv2
import numpy as np
from datetime import datetime

from core.paths import get_paths, ensure_folders


def _get_haar_cascade(paths):
    # Try project asset first.
    cascade_path = paths.haarcascade_path
    if os.path.exists(cascade_path):
        face_cascade = cv2.CascadeClassifier(cascade_path)
        if not face_cascade.empty():
            return face_cascade

    candidates = [
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml",
        "haarcascade_frontalface_default.xml",
    ]
    for p in candidates:
        if os.path.exists(p):
            fc = cv2.CascadeClassifier(p)
            if not fc.empty():
                return fc

    raise FileNotFoundError(
        "Haarcascade XML not found."
    )


def _load_label_map(paths):
    if not os.path.exists(paths.label_map_path):
        raise FileNotFoundError(
            "label_map.csv not found. Train the model first."
        )

    mapping = {}  # id -> name
    with open(paths.label_map_path, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader, None)
        if header is None:
            return mapping
        for row in reader:
            if len(row) >= 2:
                _id = int(row[0])
                mapping[_id] = row[1]
    return mapping


def train_model():
    """Train LBPH recognizer from dataset folder and save model + label map."""

    paths = get_paths()
    ensure_folders(paths)

    dataset_dir = paths.dataset_dir
    if not os.path.exists(dataset_dir):
        raise FileNotFoundError("Dataset folder not found. Register students first.")

    face_cascade = _get_haar_cascade(paths)

    label_map = {}  # id -> name
    current_id = 0

    faces = []
    ids = []

    # Iterate over student folders
    for student_name in sorted(os.listdir(dataset_dir)):
        student_path = os.path.join(dataset_dir, student_name)
        if not os.path.isdir(student_path):
            continue

        # Each image is already a cropped/gray face in our capture code
        images = [
            os.path.join(student_path, fn)
            for fn in os.listdir(student_path)
            if fn.lower().endswith((".png", ".jpg", ".jpeg"))
        ]

        if not images:
            continue

        label_map[current_id] = student_name

        for img_path in images:
            img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
            if img is None:
                continue

            # Ensure expected size
            img = cv2.resize(img, (200, 200))

            faces.append(img)
            ids.append(current_id)

        current_id += 1

    if not faces:
        raise RuntimeError("No face images found in dataset. Register students first.")

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.train(faces, np.array(ids))

    # Save model
    recognizer.write(paths.model_path)

    # Save label map
    with open(paths.label_map_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["id", "Student Name"])
        for _id, name in label_map.items():
            writer.writerow([_id, name])


def _is_already_marked(paths, student_name: str, date_str: str) -> bool:
    if not os.path.exists(paths.attendance_csv):
        return False

    with open(paths.attendance_csv, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader, None)
        for row in reader:
            if len(row) >= 2:
                if row[0] == student_name and row[1] == date_str:
                    return True
    return False


def mark_attendance():
    """Use webcam to detect + recognize and write attendance to CSV."""

    paths = get_paths()
    ensure_folders(paths)

    if not os.path.exists(paths.model_path):
        raise FileNotFoundError("Model not found. Click 'Train Model' first.")

    face_cascade = _get_haar_cascade(paths)

    label_map = _load_label_map(paths)

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read(paths.model_path)

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        raise RuntimeError("Could not open webcam. Check camera permissions.")

    # Stop after marking once (simplifies mini project)
    marked = False

    date_str = datetime.now().strftime("%Y-%m-%d")
    time_str = datetime.now().strftime("%H:%M:%S")

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                continue

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.2,
                minNeighbors=5,
                minSize=(60, 60),
            )

            for (x, y, w, h) in faces:
                roi = gray[y : y + h, x : x + w]
                roi = cv2.resize(roi, (200, 200))

                # LBPH returns label_id and confidence
                label_id, confidence = recognizer.predict(roi)

                # Heuristic threshold for LBPH: lower confidence => better match.
                # You can adjust if needed.
                is_known = confidence < 70

                if label_id in label_map and is_known:
                    name = label_map[label_id]
                else:
                    name = "Unknown"

                # Draw overlay
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                cv2.putText(
                    frame,
                    f"{name} ({confidence:.1f})",
                    (x, y - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    (0, 255, 0) if name != "Unknown" else (0, 0, 255),
                    2,
                    cv2.LINE_AA,
                )

                if name != "Unknown" and not marked:
                    if not _is_already_marked(paths, name, date_str):
                        with open(paths.attendance_csv, "a", newline="", encoding="utf-8") as f:
                            writer = csv.writer(f)
                            writer.writerow([name, date_str, datetime.now().strftime("%H:%M:%S")])

                        marked = True
                    else:
                        marked = True  # already marked today; exit loop

                    break

            cv2.imshow("AttendAI - Mark Attendance (Press ESC to stop)", frame)
            key = cv2.waitKey(1) & 0xFF
            if key == 27:
                break

            if marked:
                # Small delay so user sees the result.
                cv2.waitKey(500)
                break

    finally:
        cap.release()
        cv2.destroyAllWindows()

