from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Paths:
    root: str

    @property
    def data_dir(self) -> str:
        return os.path.join(self.root, "data")

    @property
    def dataset_dir(self) -> str:
        return os.path.join(self.data_dir, "dataset")

    @property
    def models_dir(self) -> str:
        return os.path.join(self.data_dir, "models")

    @property
    def attendance_dir(self) -> str:
        return os.path.join(self.data_dir, "attendance")

    @property
    def attendance_csv(self) -> str:
        return os.path.join(self.attendance_dir, "attendance.csv")

    @property
    def model_path(self) -> str:
        return os.path.join(self.models_dir, "lbph_model.yml")

    @property
    def label_map_path(self) -> str:
        return os.path.join(self.models_dir, "label_map.csv")

    @property
    def haarcascade_path(self) -> str:
        # Look in project folder first, then fall back to OpenCV default guesses.
        return os.path.join(self.root, "assets", "haarcascade_frontalface_default.xml")


def get_paths() -> Paths:
    # CWD might vary, so anchor to this file's location.
    here = os.path.dirname(os.path.abspath(__file__))
    core_dir = os.path.dirname(here)
    project_root = os.path.dirname(core_dir)
    return Paths(root=project_root)


def ensure_folders(paths: Paths) -> None:
    os.makedirs(paths.data_dir, exist_ok=True)
    os.makedirs(paths.dataset_dir, exist_ok=True)
    os.makedirs(paths.models_dir, exist_ok=True)
    os.makedirs(paths.attendance_dir, exist_ok=True)

    # Ensure attendance.csv exists with header
    if not os.path.exists(paths.attendance_csv):
        with open(paths.attendance_csv, "w", encoding="utf-8") as f:
            f.write("Student Name,Date,Time\n")

