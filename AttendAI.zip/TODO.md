# AttendAI - Smart Attendance System (TODO)

- [x] Create project folder structure under `smart-attendance-ai/`
- [x] Add README.md with:
  - [x] pip install commands
  - [x] step-by-step setup
  - [x] how to run
- [x] Implement Tkinter GUI with 4 buttons: Register, Train, Mark Attendance, View Attendance
- [x] Implement webcam capture + Haarcascade frontal face detection
- [x] Save student face images into `data/dataset/<Student Name>/`
- [x] Train LBPH recognizer from dataset and save model + label map
- [x] Mark attendance into `data/attendance/attendance.csv` with Student Name, Date, Time
- [x] Prevent duplicate attendance on same day
- [x] Add automatic folder creation on startup
- [x] Provide runnable entrypoint `app.py`

