from __future__ import annotations

import os
import time
import cv2

from core.paths import get_paths, ensure_folders


def _get_haar_cascade(paths):
    # Try project asset first.
    cascade_path = paths.haarcascade_path
    if os.path.exists(cascade_path):
        face_cascade = cv2.CascadeClassifier(cascade_path)
        if not face_cascade.empty():
            return face_cascade

    # Fallback: OpenCV's built-in haarcascades (varies by installation)
    # We'll try a couple of common locations.
    candidates = [
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml",
        "haarcascade_frontalface_default.xml",
    ]
    for p in candidates:
        if os.path.exists(p):
            fc = cv2.CascadeClassifier(p)
            if not fc.empty():
                return fc

    raise FileNotFoundError(
        "Haarcascade XML not found.\n"
        "Expected at: "
        f"{paths.haarcascade_path}\n"
        "and also checked OpenCV defaults."
    )


def register_student(student_name: str, num_samples: int = 50, face_min_size: int = 60):
    """Capture face images for a new student using webcam + Haarcascade."""

    paths = get_paths()
    ensure_folders(paths)

    student_dir = os.path.join(paths.dataset_dir, student_name)
    os.makedirs(student_dir, exist_ok=True)

    face_cascade = _get_haar_cascade(paths)

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        raise RuntimeError("Could not open webcam. Check camera permissions.")

    collected = 0
    last_saved_time = 0.0

    try:
        while collected < num_samples:
            ret, frame = cap.read()
            if not ret:
                continue

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.2,
                minNeighbors=5,
                minSize=(face_min_size, face_min_size),
            )

            # Draw detections
            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

                # Save only one face region at a time for beginner simplicity
                roi = gray[y : y + h, x : x + w]

                # Throttle saving (avoid saving too fast)
                now = time.time()
                if now - last_saved_time > 0.25:
                    img_path = os.path.join(student_dir, f"{student_name}_{collected:03d}.png")
                    roi = cv2.resize(roi, (200, 200))
                    cv2.imwrite(img_path, roi)
                    collected += 1
                    last_saved_time = now

                break

            cv2.imshow("AttendAI - Register (Press ESC to stop)", frame)
            key = cv2.waitKey(1) & 0xFF
            if key == 27:  # ESC
                break

        # Note: if user stopped early, still keep what was captured.
    finally:
        cap.release()
        cv2.destroyAllWindows()

