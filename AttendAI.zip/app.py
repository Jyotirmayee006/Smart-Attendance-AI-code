"""AttendAI - Smart Attendance System
Entry point for Tkinter GUI.

Run:
  python app.py
"""

from tkinter import Tk

from ui.gui import AttendAIGUI


def main():
    root = Tk()
    app = AttendAIGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()

