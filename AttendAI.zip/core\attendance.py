from __future__ import annotations

import os
import csv

from core.paths import get_paths, ensure_folders


def load_attendance_csv():
    """Return attendance rows as list of tuples: (name, date, time)."""
    paths = get_paths()
    ensure_folders(paths)

    if not os.path.exists(paths.attendance_csv):
        return []

    rows = []
    with open(paths.attendance_csv, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader, None)
        for row in reader:
            if len(row) >= 3:
                rows.append((row[0], row[1], row[2]))
    return rows

