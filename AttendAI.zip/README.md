# AttendAI - Smart Attendance System (Python + OpenCV + Tkinter)

Professional project title: **AttendAI - Smart Attendance System**

This project lets you:
- Register students (capture face images from webcam)
- Train a face recognition model
- Mark attendance using webcam
- View attendance records

It uses:
- **Haarcascade** (frontal face detection)
- **OpenCV LBPH** (beginner-friendly face recognition)
- **Tkinter** GUI
- **CSV** storage (Student Name, Date, Time)

---

## 1) Folder Structure
Created under:
`C:/Users/jyoti/Desktop/smart-attendance-ai/`

Important generated folders:
- `data/dataset/<Student Name>/`  (saved face images)
- `data/models/`                  (trained model + label map)
- `data/attendance/attendance.csv`

The code auto-creates missing folders on startup.

---

## 2) Required Libraries (pip install)
Open VS Code terminal and run:

```bash
pip install opencv-contrib-python
pip install numpy
```

Tkinter is usually included with Python on Windows, so you typically **do not need to pip install it**.

> If you get an error about `cv2.face`, install `opencv-contrib-python` (above). That package includes the `face` module.

---

## 3) How to Run
1. Open a terminal in this project folder:

```bash
cd C:/Users/jyoti/Desktop/smart-attendance-ai
```

2. Start the GUI:

```bash
python app.py
```

---

## 4) Step-by-Step Usage
### A) Register New Student
1. Enter **Student Name** in the textbox
2. Click **1. Register New Student**
3. A webcam window opens.
4. Keep your face in front of the camera.
5. The app saves face images automatically when faces are detected.
6. Press **ESC** to stop early.

### B) Train Model
1. Click **2. Train Model**
2. The model trains on all images inside `data/dataset/`
3. Trained files are saved in `data/models/`

### C) Mark Attendance
1. Click **3. Mark Attendance**
2. Webcam opens and detects + recognizes faces
3. Attendance is written to:
   `data/attendance/attendance.csv`
4. Message shown:
   **"Attendance Marked Successfully"**

### Duplicate Prevention
- If a student is already marked on the **same date**, the CSV will not duplicate the entry.

### D) View Attendance
- Click **4. View Attendance**
- Records display inside the GUI table.

---

## 5) Sample Output Screenshots (Description)
1. **Main GUI Window**
   - Title: *AttendAI - Smart Attendance System*
   - A Student Name input box
   - Four buttons (Register / Train / Mark / View)
   - Empty table area labeled *Attendance Records*

2. **Webcam Capture Window (Register)**
   - Live webcam view
   - Green rectangle around detected face
   - Labeling is minimal for beginner clarity

3. **Training Step**
   - No webcam window; GUI shows status like *Training model...*
   - Message box: *Training Completed.*

4. **Webcam Attendance Window (Mark)**
   - Live webcam view with a label on the face, e.g.:
     - `Amit (43.2)`
   - After marking, window closes.
   - Message box: *Attendance Marked Successfully*

5. **Attendance Table (View Attendance)**
   - Table with columns:
     - Student Name | Date | Time

---

## Troubleshooting
- **Webcam not opening**: check permissions and camera connection.
- **`cv2.face` missing**: ensure you installed `opencv-contrib-python`.
- **No face images saved**: keep face clearly visible; adjust lighting.


