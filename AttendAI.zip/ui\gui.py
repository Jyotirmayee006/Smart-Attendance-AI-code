import tkinter as tk
from tkinter import ttk, messagebox

from core.dataset import register_student
from core.recognition import train_model, mark_attendance
from core.attendance import load_attendance_csv


class AttendAIGUI:
    """Simple modern-ish Tkinter GUI for the AttendAI mini project."""

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("AttendAI - Smart Attendance System")
        self.root.geometry("980x640")
        self.root.minsize(850, 560)

        style = ttk.Style(self.root)
        # Default theme tweaks for readability
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        container = ttk.Frame(root, padding=18)
        container.pack(fill="both", expand=True)

        title = ttk.Label(
            container,
            text="AttendAI - Smart Attendance System",
            font=("Segoe UI", 20, "bold"),
        )
        title.pack(pady=(0, 14))

        # Top controls
        controls = ttk.Frame(container)
        controls.pack(fill="x")

        ttk.Label(controls, text="Student Name:", font=("Segoe UI", 11)).grid(
            row=0, column=0, sticky="w"
        )
        self.student_name_var = tk.StringVar()
        name_entry = ttk.Entry(controls, textvariable=self.student_name_var, width=30)
        name_entry.grid(row=0, column=1, padx=(10, 0), sticky="w")

        btn_frame = ttk.Frame(container)
        btn_frame.pack(fill="x", pady=(14, 10))

        ttk.Button(
            btn_frame,
            text="1. Register New Student",
            command=self.on_register,
        ).grid(row=0, column=0, padx=8, pady=6, sticky="ew")

        ttk.Button(
            btn_frame,
            text="2. Train Model",
            command=self.on_train,
        ).grid(row=0, column=1, padx=8, pady=6, sticky="ew")

        ttk.Button(
            btn_frame,
            text="3. Mark Attendance",
            command=self.on_mark,
        ).grid(row=0, column=2, padx=8, pady=6, sticky="ew")

        ttk.Button(
            btn_frame,
            text="4. View Attendance",
            command=self.on_view,
        ).grid(row=0, column=3, padx=8, pady=6, sticky="ew")

        for i in range(4):
            btn_frame.grid_columnconfigure(i, weight=1)

        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status = ttk.Label(container, textvariable=self.status_var, anchor="w")
        status.pack(fill="x", pady=(10, 12))

        # Attendance table
        table_frame = ttk.LabelFrame(container, text="Attendance Records")
        table_frame.pack(fill="both", expand=True)

        columns = ("Student Name", "Date", "Time")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings")
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=220 if col != "Time" else 160, anchor="center")

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)

        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

    def _set_status(self, text: str):
        self.status_var.set(text)
        self.root.update_idletasks()

    def _get_student_name(self) -> str:
        name = self.student_name_var.get().strip()
        return name

    def on_register(self):
        name = self._get_student_name()
        if not name:
            messagebox.showwarning("Missing Name", "Please enter Student Name first.")
            return

        if not messagebox.askyesno(
            "Register Student",
            f"Register faces for '{name}'?\n\nWebcam window will open.",
        ):
            return

        self._set_status("Registering student (webcam open)...")
        try:
            register_student(name)
        except Exception as e:
            messagebox.showerror("Error", str(e))
            self._set_status("Error")
            return

        self._set_status("Student registered successfully")
        messagebox.showinfo("Done", f"Saved face images for '{name}'.")

    def on_train(self):
        self._set_status("Training model (this may take a moment)...")
        try:
            train_model()
        except Exception as e:
            messagebox.showerror("Error", str(e))
            self._set_status("Error")
            return

        self._set_status("Model trained successfully")
        messagebox.showinfo("Done", "Training Completed.")

    def on_mark(self):
        self._set_status("Marking attendance (webcam open)...")
        try:
            mark_attendance()
        except Exception as e:
            messagebox.showerror("Error", str(e))
            self._set_status("Error")
            return

        self._set_status("Attendance Marked Successfully")
        messagebox.showinfo("Done", "Attendance Marked Successfully")

    def on_view(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        try:
            rows = load_attendance_csv()
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return

        if not rows:
            self._set_status("No attendance records found yet")
            return

        for r in rows:
            self.tree.insert("", "end", values=(r[0], r[1], r[2]))
        self._set_status(f"Loaded {len(rows)} records")

